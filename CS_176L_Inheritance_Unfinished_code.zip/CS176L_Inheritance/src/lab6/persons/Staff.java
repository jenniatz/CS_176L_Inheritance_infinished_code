package lab6.persons;

public class Staff extends Employee {
	
	private String title;
	
	
	public Staff() {
		super();
		// TODO Auto-generated constructor stub
	}







	public Staff(String officeNumber, Double salary) {
		super(officeNumber, salary);
		// TODO Auto-generated constructor stub
	}







	public Staff(String officeNumber, Double salary, String title) {
		super(officeNumber, salary);
		this.title = title;
	}

	
	
	



//	public Staff(String officeNumber, Double salary) {
//		super(officeNumber, salary);
//		// TODO Auto-generated constructor stub
//	}

	

	



	public String getTitle() {
		return title;
	}

	



	public void setTitle(String title) {
		this.title = title;
	}

	public String toString() {
		String s = super.toString();
		return s + "," + this.title;
	}
	
	
}
