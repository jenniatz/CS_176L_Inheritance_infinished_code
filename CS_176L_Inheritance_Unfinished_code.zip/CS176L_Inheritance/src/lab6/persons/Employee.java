package lab6.persons;

public class Employee extends Person {
	private String officeNumber;
	private Double salary;
	
//	public Employee() {
//		super();
//		// TODO Auto-generated constructor stub
//	}

	
	public Employee(String officeNumber, Double salary) {
		super();
		this.officeNumber = officeNumber;
		this.salary = salary;
	}

	
	
//	public Employee(String name, double salary) {
//		super();
//		
//	}
	
	


	public Employee() {
		super();
		this.officeNumber = " ";
		this.salary = 0.0;
	}



	public String getOfficeNumber() {
		return officeNumber;
	}
	public Double getSalary() {
		return salary;
	}
	public void setOfficeNumber(String officeNumber) {
		this.officeNumber = officeNumber;
	}
	
	public void setSalary(double salary) {
		this.salary = salary;
	} 

	public String toString() {
		String s = super.toString();
		return s + "," + this.officeNumber + "," + this.salary;
	}
	
}
