package lab6.persons;

public class Faculty extends Employee {
	private String rank;
	
	
	public Faculty() {
		super();
		// TODO Auto-generated constructor stub
	}

	

	public Faculty(String officeNumber,Double salary) {
		super(officeNumber, salary);
		// TODO Auto-generated constructor stub
	}



	
	public String getRank() {
		return rank;
	}

	public void setRank(String rank) {
		this.rank = rank;
	}
	public String toString() {
		String s = super.toString();
		return s + "," + this.rank;
	}



	
	
	
	
}
