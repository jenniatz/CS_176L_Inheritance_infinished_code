package lab6.persons;
/**
 * 
 * @author Jenni A
 * extends is to reference the super class persons
 *
 */
public class Student extends Person {

	 public static final int FRESHMAN = 1;
     public static final int SOPHOMORE = 2;
     public static final int JUNIOR = 3;
     public static final int SENIOR = 4;
     public static final int SUPERSENIOR = 5;

	private int year;

	Student(){	
	
		super();
}	
	public Student(int year) {
		super();
		this.year = year;
	}
	
	
	
	public void setYear(int year) {
		this.year = year;
		
		
		
	}
	public String toString() {
		String s = super.toString();
		 return s + "," + this.year;
	}

		
	
}
